# FaceAI Nodejs
Face Detection, Facial Expression Detection, and Age Gender Detection Nodejs Web App

# See Demo

https://faceai.herokuapp.com/

# Install

```
Download NodeJs From NodeJs Website And Install

Run Terminal Or CMD And Go To Your Project Folder

Then Run npm install to install all dependencies

At Last Run npm start

Open Browser And Type http://localhost:3000

```
